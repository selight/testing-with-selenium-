import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;

import java.io.PrintWriter;
import java.util.List;

public class PortalLogin{
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws InterruptedException {
// Create a new instance of the Firefox driver
        System.setProperty("webdriver.gecko.driver", "/home/paix/Downloads/geckodriver/geckodriver");
        WebDriver driver;
        driver = new FirefoxDriver();
//Launch the some site
        driver.get("https:/portal.aait.edu.et/");
        driver.findElement(By.xpath("//*[@id=\"UserName\"]")).sendKeys("ATR/2042/09");
        driver.findElement(By.xpath("//*[@id=\"Password\"]")).sendKeys("4805");
        driver.findElement(By.xpath("//*[@id=\"home\"]/div[2]/div[2]/form/div[4]/div/button")).click(); // Identifier for Next button

// Navigate to the gradeReport
        driver.navigate().to("https://portal.aait.edu.et/Grade/GradeReport");
        String gradeOutput = driver.findElement(By.xpath("/html/body/div[2]/div/div[2]/div[1]/div")).getText();
        System.out.println(gradeOutput);
        try{
            PrintWriter writer = new PrintWriter("gradefile.txt", "UTF-8");
            writer.println(gradeOutput);
            writer.close();
        }catch(Exception e){
            e.printStackTrace();
        }
// Close the driver
        driver.quit();
    }
}
