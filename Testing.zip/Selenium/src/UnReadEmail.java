import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class UnReadEmail {
public static void main(String[] args) throws InterruptedException, IOException {
        
        System.setProperty("webdriver.gecko.driver", "/home/paix/Downloads/geckodriver/geckodriver");
        // Create a new instance of the FireFox driver
        WebDriver driver = new FirefoxDriver();
        // Storing the Application Url in the String variable
        String url = "https://mail.google.com/mail";
        //Launch the localhost WebSite
        driver.get(url);

        WebElement email = driver.findElement(By.name("identifier"));
       

        email.sendKeys("ghiwotselam@gmail.com");

        WebElement next = driver.findElement(By.id("identifierNext"));
        next.click();
        Thread.sleep(650);
        WebElement password = driver.findElement(By.name("password"));
        password.sendKeys("Passwordstrength1");
        Thread.sleep(350);
        WebElement passnext = driver.findElement(By.id("passwordNext"));
        passnext.click();
        
        Thread.sleep(250);
        List<WebElement> mail=driver.findElements(By.xpath("//*[@class='zA zE']"));
        String message="";
        for(int i=0; i<mail.size(); i++){
            //System.out.println("main: "+ );
            String from="from: "+mail.get(i).findElement(By.className("zF")).getAttribute("name");
            String subject= "subject: "+mail.get(i).findElement(By.className("y6")).getText();
            message += from+ "  "+ subject+ "\n";
        }
        export(message);

    }
     public static void export(String data) throws IOException 
{
	FileWriter fileWriter = new FileWriter("export.txt");
        PrintWriter printWriter = new PrintWriter(fileWriter);
        printWriter.print(data);
        printWriter.close();
}
}
